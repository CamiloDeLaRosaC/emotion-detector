"""Flask web server for the Emotion Detector application."""

from flask import Flask, render_template, request
from requests import RequestException

from EmotionDetection.emotion_detection import emotion_detector


app = Flask(__name__)


@app.route("/")
def render_index_page():
    """Render the application home page."""
    return render_template("index.html")


@app.route("/emotionDetector")
def detect_emotion():
    """Analyze the text supplied by the web interface."""
    text_to_analyse = request.args.get("textToAnalyze", "")
    try:
        response = emotion_detector(text_to_analyse)
    except (RequestException, KeyError, IndexError, ValueError):
        return "The emotion service is temporarily unavailable. Please try again.", 503

    if response["dominant_emotion"] is None:
        return "Invalid input! Try again."

    return (
        "For the given statement, the system response is "
        f"'anger': {response['anger']}, "
        f"'disgust': {response['disgust']}, "
        f"'fear': {response['fear']}, "
        f"'joy': {response['joy']} and "
        f"'sadness': {response['sadness']}. "
        f"The dominant emotion is {response['dominant_emotion']}."
    )


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000)
